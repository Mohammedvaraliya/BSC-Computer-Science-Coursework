# WAP to read an existing file.

f = open("D:\\python Projects\\BSC-CS-Practical-Performed\\BSC CS\\FY\SEM-2\\Advanced Python Programming\\practical-1\\hello.txt",'r')
a = f.read()
print(a)